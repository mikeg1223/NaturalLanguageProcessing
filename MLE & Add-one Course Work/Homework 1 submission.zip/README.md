
##Instructions on running main:
---

1. Verify you have an installation of python on your machin
2. Go to the directory containing main.py, test.txt, and train-Spring2022.txt in your prefered shell.
3. run main.py using the command: python main.py 
4. Read the console output for questions answered in order: 3, 1, 2, 4, 5 ,6 , and 7